../../architectural-analysis/scripts/render.sh
