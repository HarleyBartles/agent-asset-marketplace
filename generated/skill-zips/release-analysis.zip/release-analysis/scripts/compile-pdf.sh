../../architectural-analysis/scripts/compile-pdf.sh
