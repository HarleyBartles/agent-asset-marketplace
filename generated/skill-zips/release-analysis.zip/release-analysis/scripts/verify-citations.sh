../../architectural-analysis/scripts/verify-citations.sh
