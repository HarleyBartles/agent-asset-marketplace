﻿# Version History for Adventures Github Operations

- Historical version: `v1.1`
- Historical source id: `adventures-github-operations-v1.1`
- Current root: `sources/first_party/skills/adventures-github-operations/SKILL.md`
- Provenance: historical archive note for adventures-github-operations
- Historical package folders folded out of the live root: `v1`

The current root is unversioned; historical version details live only in this note and the changelog.
