# Version History for Base Doctrine

- Historical version: `v1.1`
- Historical source id: `gpt-base-doctrine-v1.1`
- Current root: `codex-marketplace/plugins/house-skills/skills/base-doctrine/SKILL.md`
- Provenance: historical archive note for base-doctrine
- Historical package folders folded out of the live root: `v1`, `v1.1`

The current root is unversioned; historical version details live only in this note and the changelog.


