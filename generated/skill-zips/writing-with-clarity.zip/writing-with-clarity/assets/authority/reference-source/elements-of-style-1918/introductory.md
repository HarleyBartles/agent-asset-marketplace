## I. Introductory

This book aims to give in brief space the principal requirements of
plain English style. It aims to lighten the task of instructor and
student by concentrating attention (in Chapters II and III) on a few
essentials, the rules of usage and principles of composition most
commonly violated. In accordance with this plan it lays down three rules
for the use of the comma, instead of a score or more, and one for the
use of the semicolon, in the belief that these four rules provide for
all the internal punctuation that is required by nineteen sentences out
of twenty. Similarly, it gives in Chapter III only those principles of
the paragraph and the sentence which are of the widest application. The
book thus covers only a small portion of the field of English style. The
experience of its writer has been that once past the essentials,
students profit most by individual instruction based on the problems of
their own work, and that each instructor has his own body of theory,
which he may prefer to that offered by any textbook.

The numbers of the sections may be used as references in correcting
manuscript.

The writer's colleagues in the Department of English in Cornell
University have greatly helped him in the preparation of his manuscript.
Mr. George McLane Wood has kindly consented to the inclusion under
Rule 10 of some material from his _Suggestions to Authors_.

The following books are recommended for reference or further study: in
connection with Chapters II and IV, F. Howard Collins, _Author and
Printer_ (Henry Frowde); Chicago University Press, _Manual of Style_;
T. L. De Vinne, _Correct Composition_ (The Century Company); Horace
Hart, _Rules for Compositors and Printers_ (Oxford University Press);
George McLane Wood, _Extracts from the Style-Book of the Government
Printing Office_ (United States Geological Survey); in connection with
Chapters III and V, _The King's English_ (Oxford University Press); Sir
Arthur Quiller-Couch, _The Art of Writing_ (Putnam), especially the
chapter, Interlude on Jargon; George McLane Wood, _Suggestions to
Authors_ (United States Geological Survey); John Lesslie Hall, _English
Usage_ (Scott, Foresman and Co.); James P. Kelley, _Workmanship in
Words_ (Little, Brown and Co.). In these will be found full discussions
of many points here briefly treated and an abundant store of
illustrations to supplement those given in this book.

It is an old observation that the best writers sometimes disregard the
rules of rhetoric. When they do so, however, the reader will usually
find in the sentence some compensating merit, attained at the cost of
the violation. Unless he is certain of doing as well, he will probably
do best to follow the rules. After he has learned, by their guidance, to
write plain English adequate for everyday uses, let him look, for the
secrets of style, to the study of the masters of literature.
