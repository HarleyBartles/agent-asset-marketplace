---
name: adventures-image-qa
description: Use when review Adventures generated candidates and compiled assets against
  source constraints and acceptance criteria, while keeping QA separate from image
  generation or editing authority.
metadata:
  source-id: adventures-image-qa
  source-path: sources/first_party/skills/adventures-image-qa/SKILL.md
  provenance-name: Adventures Image Qa first-party skill
  source-category: first_party
  status: active
  owner: Harley Bartles
  scope: Use when review Adventures generated candidates and compiled assets against
    source constraints and acceptance criteria, while keeping QA separate from image
    generation or editing authority.
  use_when:
  - Use when review Adventures generated candidates and compiled assets against source
    constraints and acceptance criteria, while keeping QA separate from image generation
    or editing authority.
  do_not_use_when:
  - Do not use when another more specific skill owns this task.
license: MIT
---
# Adventures Image Qa

Use this skill when Adventures work needs visual QA of generated candidates, reference art, or compiled sheets.

## Owned decision

Decide whether the asset is ready for acceptance, needs repair, or should route to another lane.

## Hard boundaries

QA does not authorize another image call.

QA is separate from generation, editing, and final acceptance.

## Minimal workflow

1. Compare the candidate to the source basis and requested lane.
2. Check the obvious failures, omissions, and drift.
3. Report the next lawful step.
4. Stop before regenerating anything.
