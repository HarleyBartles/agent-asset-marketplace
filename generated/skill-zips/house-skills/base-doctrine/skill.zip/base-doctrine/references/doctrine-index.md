# Doctrine index

Use this map to avoid loading all doctrine.

- `system-prompt-contract.md`: project/system prompt length, character counting, and prompt bloat avoidance.
- `tool-surface-and-evidence.md`: current session tool surface, product settings versus callable tools, memory claims, unavailable claims, and evidence layers.
- `durable-doctrine-routing.md`: where to store durable rules and agent assets: system prompt, skills, canonical source repos, Codex plugin marketplaces, repo overlays, playbooks, repo docs, project sources, Linear, or memory.
- `failure-and-trust-posture.md`: correction, no handwaving, and verified-versus-inferred language.
- `output-artifact-shape.md`: output form as authority, reserved YAML shapes, dispatch/session-buster confusion, and worker-copy attention guards.


