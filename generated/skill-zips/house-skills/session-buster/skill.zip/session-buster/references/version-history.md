# Version History for Session Buster

- Historical version: `v0.2`
- Historical source id: `session-buster-v0.2`
- Current root: `codex-marketplace/plugins/house-skills/skills/session-buster/SKILL.md`
- Provenance: historical archive note for session-buster
- Historical package folders folded out of the live root: `v0.1`

The current root is unversioned; historical version details live only in this note and the changelog.
