# Version History for Boring Buster

- Historical version: `v1`
- Historical source id: `boring-buster-v1`
- Current root: `codex-marketplace/plugins/house-skills/skills/boring-buster/SKILL.md`
- Provenance: historical archive note for boring-buster
- Historical package folders folded out of the live root: none

The current root is unversioned; historical version details live only in this note and the changelog.
