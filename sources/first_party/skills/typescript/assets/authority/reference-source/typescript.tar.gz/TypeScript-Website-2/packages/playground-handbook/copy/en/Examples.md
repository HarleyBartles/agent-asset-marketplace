## Examples

The Playground examples are an interactive set of tutorials, and overviews into parts of TypeScript with a very tight focus. They are not as comprehensive as [the TypeScript handbook](/docs/handbook/intro.html), but they aim to offer a 2nd explanation (with different metaphors and ideas) inside comments of a Playground which invites the writer to fidget with the code and see how the pieces come together.

<details><summary>Speaking as the author, ...</summary>

Speaking as the author, I, _Orta_, think there are many ways for people to learn a complex subject. I don't think it's possible to just pick up a single book and _" :tada: I understand X."_ We're not learning kung-fu in a second, something like TypeScript takes a while to learn.

I believe that studying something complex revolves around creating a mesh of understanding by mixing learning and doing. The TypeScript handbook does a great job of covering all the primitives of TypeScript, and you can study it, but with the Playground we have a space for a 2nd explanation on the same topics with an environment structured for play and safe failure. The Examples in the Playground are built to encourage exploration of ideas.

</details>

You can access the examples via the Playground toolbar for both "Examples" and "What's New" - there's also links in the footer of every page (except the homepage.)

The Playground examples are structured into 3 main sections:

- **TypeScript** - covering type syntax primitives, terms which may be new to people, and language extensions
- **JavaScript** - showing how TypeScript types can interact with runtime code, how to work with different environments and existing JavaScript structures
- **What's new** - Per-release feature specific explanations of new language changes

The examples that you have read are tracked in your browser via `localStorage`, and you get see a blue dot next to something you have read in the dropdown. If that blue dot is empty, it means the example has been updated since you last read it.
