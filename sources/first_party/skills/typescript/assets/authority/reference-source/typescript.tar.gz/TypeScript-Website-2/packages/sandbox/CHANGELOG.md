# @typescript/sandbox

## 0.1.14

### Patch Changes

- [#3523](https://github.com/microsoft/TypeScript-Website/pull/3523) [`9953d5b`](https://github.com/microsoft/TypeScript-Website/commit/9953d5bf9168335e3ddad7b1752b3213f3f9a636) Thanks [@Josh-Cena](https://github.com/Josh-Cena)! - getInitialCode should not use URL hash without full prefix

## 0.1.13

### Patch Changes

- [#3505](https://github.com/microsoft/TypeScript-Website/pull/3505) [`2072484`](https://github.com/microsoft/TypeScript-Website/commit/20724842b6eaf09f5c5d0ee40272c5569fe5c37d) Thanks [@DanielRosenwasser](https://github.com/DanielRosenwasser)! - Fix Ctrl+arrow keys in Firefox.

## 0.1.12

### Patch Changes

- Updated dependencies [[`0daa298`](https://github.com/microsoft/TypeScript-Website/commit/0daa298f2f4526f8c66baff00b8df0290e37a4d4)]:
  - @typescript/vfs@1.6.4

## 0.1.11

### Patch Changes

- Updated dependencies [[`5e2b828`](https://github.com/microsoft/TypeScript-Website/commit/5e2b8285e01edffd888aa97002d082f6975f7bc1)]:
  - @typescript/vfs@1.6.3

## 0.1.10

### Patch Changes

- Updated dependencies [[`1843cf4`](https://github.com/microsoft/TypeScript-Website/commit/1843cf45e06193b3dc072088785fe2bfad477de5)]:
  - @typescript/vfs@1.6.2

## 0.1.9

### Patch Changes

- Updated dependencies [[`5e10fd0`](https://github.com/microsoft/TypeScript-Website/commit/5e10fd05e4fd5ac42ac4e95baecaa7b8b0e8fa19)]:
  - @typescript/ata@0.9.8

## 0.1.8

### Patch Changes

- Updated dependencies [[`4a30b02`](https://github.com/microsoft/TypeScript-Website/commit/4a30b022bc0c1df6b6abb71c99c104f3b19f2c91)]:
  - @typescript/vfs@1.6.1

## 0.1.7

### Patch Changes

- Updated dependencies [[`1d0af97`](https://github.com/microsoft/TypeScript-Website/commit/1d0af97318b79943fe0bfa8871ee6e8c584c9af5)]:
  - @typescript/ata@0.9.7

## 0.1.6

### Patch Changes

- Updated dependencies [[`441338c`](https://github.com/microsoft/TypeScript-Website/commit/441338c04fbbef834ffa1ac6dc0dc8816e9137fc), [`725841a`](https://github.com/microsoft/TypeScript-Website/commit/725841adc9e5b734ccb0663fccb2ba05d0dcca62)]:
  - @typescript/vfs@1.6.0

## 0.1.5

### Patch Changes

- [#3000](https://github.com/microsoft/TypeScript-Website/pull/3000) [`71776ae`](https://github.com/microsoft/TypeScript-Website/commit/71776aecc1b56289ab56d240a9272ce83686ef1a) Thanks [@antfu](https://github.com/antfu)! - Handle `.d.cts` and `.d.mts` files

- Updated dependencies [[`0ea84b5`](https://github.com/microsoft/TypeScript-Website/commit/0ea84b59ae291aba677fe77ca059c4112e45fb9b), [`7691811`](https://github.com/microsoft/TypeScript-Website/commit/7691811c180e3b352cf4e888387d1edfc10f5252), [`0ea84b5`](https://github.com/microsoft/TypeScript-Website/commit/0ea84b59ae291aba677fe77ca059c4112e45fb9b), [`6168ef4`](https://github.com/microsoft/TypeScript-Website/commit/6168ef49a4d08c0b5658732d23625bbcc6049109), [`9f8dea2`](https://github.com/microsoft/TypeScript-Website/commit/9f8dea2c19a3b6028148090f5e8cba8eea086ec3), [`26f3e56`](https://github.com/microsoft/TypeScript-Website/commit/26f3e566aa8fff235a8f6927ef2c33b28be4fe89), [`71776ae`](https://github.com/microsoft/TypeScript-Website/commit/71776aecc1b56289ab56d240a9272ce83686ef1a), [`fd776c0`](https://github.com/microsoft/TypeScript-Website/commit/fd776c05bb8fa9c897d18fa237af39ae8da03a7c)]:
  - @typescript/vfs@1.5.3
  - @typescript/ata@0.9.6

## 0.1.4

### Patch Changes

- Updated dependencies [642ea11]
  - @typescript/vfs@1.5.2

## 0.1.3

### Patch Changes

- 46eba14: Initial bump for changesets
- Updated dependencies [46eba14]
  - @typescript/vfs@1.5.1
  - @typescript/ata@0.9.5
