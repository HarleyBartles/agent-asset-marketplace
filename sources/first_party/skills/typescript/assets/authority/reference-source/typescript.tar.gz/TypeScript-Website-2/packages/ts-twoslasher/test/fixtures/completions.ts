console.log
//       ^|
