let foo = "hello there!";
//  ^?
